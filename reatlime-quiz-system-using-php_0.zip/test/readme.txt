How to Run
Download the source code and extract the zip file.

Download or set up any local web server that runs PHP script.

Make sure uncomment the "​​​​​​​extension=sockets" line in your php.ini file.

Run the php-socket.php file in your command line or terminal. [php php-socket.php]

Open the web-server database and create a new database name it realtime_quiz_db.

Import the SQL file located in the database folder of the source code.

Copy and paste the source code to the location where your local web server accessing your local projects. Example for XAMPP('C:\xampp\htdocs')

Open a web browser and browse the project. E.g [http://localhost/realtime-quiz-system-using-php]

Default Admin Access
Username: admin

Password: admin123

There it is, the realtime quiz system is ready to use.

I hope this simple realtime quiz system will help you with what you are looking for. Feel free to download and modify the source code.

Explore more on this website for more source codes and tutorials.

Enjoy!