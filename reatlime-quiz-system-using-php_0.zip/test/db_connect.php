<?php 

$conn= new mysqli('localhost','root','','realtime_quiz_db')or die("Could not connect to mysql".mysqli_error($con));
